

#!/usr/bin/perl

use warnings;
use strict;
use DateTime;
use libs;


# Initialize the global variables. 

#Linux
# my $workspace = "\/home\/parallels\/Desktop\/workspace2\/NVL\/";

#Windows 
my $workspace = "C:\\Users\\kerimcakmak\\workspace2\\NVL\\SETitanic\\";

my $rhapsody_file_dir = "Projekt_SETitanic_rpy\\";

my $fullPath = $workspace . "" . $rhapsody_file_dir;
my $searchPath = $fullPath . "\*.\*";
my $projectArea = "iOjfYfj9Eeyg2Yb4jthRGQ";
my $connectTemplate = "connection_template.xml";
my $connectIndexTemplate = "connection_index_template.xml";

# inputs
my $fromPart = $ARGV[0];
my $fromPort = $ARGV[1];
my $toPart = $ARGV[2];
my $toPort = $ARGV[3]; 


my $origFileContents = "";
my $fromPartFileContents = "";
my $toPartFileContents = ""; 
my $fromBlockFileContents = "";
my $toBlockFileContents = ""; 
my $parentGuid = "";
my $parentPackage = "";


# Other required information 
my $connName = ""; 
my $connGUID = ""; 
my $connRMID = ""; 
my $toPartName = $toPart;
my $fromPartName = $fromPart;
my $toBlockName = "";
my $fromBlockName = "";
my $parentFromBlock = ""; 
my $parentToBlock = "";
my $toPartGUID = "";
my $toPartRMID = "";
my $fromPartGUID = "";
my $fromPartRMID = ""; 
my $toPortGUID = "";
my $toPortRMID = ""; 
my $fromPortGUID = ""; 
my $fromPortRMID = ""; 

$connName = $toPartName . "_" . $fromPartName; 
my $connIds = getIds($searchPath);
($connGUID, $connRMID) = split(/,/,$connIds); 
$connName = $fromPartName . "_" . $toPartName; 

my $toPartFileNames = `findstr $toPartName $searchPath`;
my $fromPartFileNames = `findstr $fromPartName $searchPath`;

my $toPartFileName = findCorrectFileName($toPartFileNames, $toPartName); 
my $fromPartFileName = findCorrectFileName($fromPartFileNames, $fromPartName);

open (READ_PRT, '<', $fromPartFileName);

while (<READ_PRT>){
	chomp($_);
	if ($fromPartFileContents eq "") {
		$fromPartFileContents = $_ . "\n";
	}
	else {
		$fromPartFileContents = $fromPartFileContents . $_ . "\n"; 
	}

}
close (READ_PRT);

if ($toPartFileName eq $fromPartFileName) {$toPartFileContents = $fromPartFileContents;}

else { 
	open (READ_PRT, '<', $toPartFileName);

	while (<READ_PRT>){
		chomp($_);
		if ($toPartFileContents eq "") {
			$toPartFileContents = $_ . "\n";
		}
		else {
			$toPartFileContents = $toPartFileContents . $_ . "\n"; 
		}

	}
	close (READ_PRT);
}


#Find from and to Block Names... 
$fromPartGUID = findGuid($fromPartName, $fromPartFileContents, "IPart");
$fromPartRMID = findRmid($fromPartName, $fromPartFileContents, "IPart");
$fromBlockName = getBlockName($fromPartName, $fromPartFileContents, "IPart"); 

$parentFromBlock = findParentName($fromPartGUID, $fromPartFileContents, "IClass");

$toPartGUID = findGuid($toPartName, $toPartFileContents, "IPart");
$toPartRMID = findRmid($toPartName, $toPartFileContents, "IPart"); 
$toBlockName = getBlockName($toPartName, $toPartFileContents, "IPart");

$parentToBlock = findParentName ($toPartGUID, $toPartFileContents, "IClass");

my $toBlockFileNames = `findstr $toBlockName $searchPath`;
my $fromBlockFileNames = `findstr $fromBlockName $searchPath`;
my $toBlockFileName = findCorrectFileName($toBlockFileNames, $toBlockName);
my $fromBlockFileName = findCorrectFileName($fromBlockFileNames, $fromBlockName);
my $parentFromBlockFileNames = `findstr $parentFromBlock $searchPath`;
my $parentFromBlockFileName = findCorrectFileName($parentFromBlockFileNames, $parentFromBlock);
my $parentToBlockFileNames = `findstr $parentToBlock $searchPath`;
my $parentToBlockFileName = findCorrectFileName($parentToBlockFileNames, $parentToBlock);

if ($fromBlockFileName eq $fromPartFileName) {$fromBlockFileContents = $toPartFileContents;}

else { 
	open (READ_PRT, '<', $fromBlockFileName);

	while (<READ_PRT>){
		chomp($_);
		if ($fromBlockFileContents eq "") {
			$fromBlockFileContents = $_ . "\n";
		}
		else {
			$fromBlockFileContents = $fromBlockFileContents . $_ . "\n"; 
		}

	}
	close (READ_PRT);
}

$fromPortGUID = findGuid($fromPort, $fromBlockFileContents, "IPort");
$fromPortRMID = findRmid($fromPort, $fromBlockFileContents, "IPort"); 

if ($toBlockFileName eq $fromPartFileName) {$toBlockFileContents = $toPartFileContents;}

else { 
	open (READ_PRT, '<', $toBlockFileName);

	while (<READ_PRT>){
		chomp($_);
		if ($toBlockFileContents eq "") {
			$toBlockFileContents = $_ . "\n";
		}
		else {
			$toBlockFileContents = $toBlockFileContents . $_ . "\n"; 
		}

	}
	close (READ_PRT);
}


$toPortGUID = findGuid($toPort, $toBlockFileContents, "IPort");
$toPortRMID = findRmid($toPort, $toBlockFileContents, "IPort"); 


open (CONN_R, '<', $connectTemplate); 
my $templContents = "";
while(<CONN_R>) {
	chomp($_); 
	if ($templContents eq "") {$templContents = $_ . "\n";}
	else {$templContents = $templContents . $_ . "\n";} 
}
close(CONN_R);


open (CONNIN_R, '<', $connectIndexTemplate); 
my $templIndexContents = "";
while(<CONNIN_R>) {
	chomp($_); 
	if ($templIndexContents eq "") {$templIndexContents = $_ . "\n";}
	else {$templIndexContents = $templIndexContents . $_ . "\n";} 
}
close(CONNIN_R);




my $mainFileName = $parentFromBlockFileName; 

# is From Part in the same file as the From Parent Block? 
if ($fromPartFileName eq $mainFileName) {
		$templContents =~s/<if_different_frompart><\/if_different_frompart>\n//ig;
}
else {
	my $fromPartDiff = "<_hfilename type=\"a\">$fromPartFileName<\/_hfilename>\n\t\t\t\t\t<_hsubsystem type=\"a\"><\/_hsubsystem>\n\t\t\t\t\t<_hclass type=\"a\">$parentFromBlock<\/_hclass>\n\t\t\t\t\t<_hname type=\"a\">$fromPart<\/_hname>";
	$templContents =~s/<if_different_frompart><\/if_different_frompart>/$fromPartDiff/ig;	
#	my $recursiveParents = getPath($fromPartGUID, $searchPath);
}

if ($toPartFileName eq $mainFileName) {
	$templContents =~s/<if_different_topart><\/if_different_topart>//ig;			
}
else {
	my $toPartDiff = "<_hfilename type=\"a\">$toPartFileName<\/_hfilename>\n\t\t\t\t\t<_hsubsystem type=\"a\"><\/_hsubsystem>\n\t\t\t\t\t<_hclass type=\"a\">$parentToBlock<\/_hclass>\n\t\t\t\t\t<_hname type=\"a\">$toPart<\/_hname>";
	$templContents =~s/<if_different_topart><\/if_different_topart>/$toPartDiff/ig;		
#	my $recursiveParents = getPath($toPartGUID, $searchPath);

}

if ($fromBlockFileName eq $mainFileName) {
	$templContents =~s/<if_different_fromport><\/if_different_fromport>//ig;
}
else {
		
	my $formPortDiff = "<_hfilename type=\"a\">$fromBlockFileName<\/_hfilename>\n\t\t\t\t\t<_hsubsystem type=\"a\"><\/_hsubsystem>\n\t\t\t\t\t<_hclass type=\"a\">$fromBlockName<\/_hclass>\n\t\t\t\t\t<_hname type=\"a\">$fromPort<\/_hname>";
	$templContents =~s/<if_different_fromport><\/if_different_fromport>/$formPortDiff/ig;
#	my $recursiveParents = getPath($fromBlockFileName, $parentFromBlock, $fromBlockName, $searchPath);
}


if ($toBlockFileName eq $mainFileName) {
	$templContents =~s/<if_different_toport><\/if_different_toport>//ig;	
}
else {
	my $toPortDiff = "<_hfilename type=\"a\">$toBlockFileName<\/_hfilename>\n\t\t\t\t\t<_hsubsystem type=\"a\"><\/_hsubsystem>\n\t\t\t\t\t<_hclass type=\"a\">$toBlockName<\/_hclass>\n\t\t\t\t\t<_hname type=\"a\">$toPort<\/_hname>";
	$templContents =~s/<if_different_toport><\/if_different_toport>/$toPortDiff/ig;
#	my $recursiveParents = getPath($toBlockFileName, $parentToBlock, $toBlockName, $searchPath);

}
my $date = getDate();
	$templContents =~s/PROJECTAREAID_HERE/$projectArea/ig;
	$templContents =~s/CURRENTDATE_HERE/$date/ig;
	$templContents =~s/TOPARTGUID_HERE/$toPartGUID/ig;
	$templContents =~s/TOPARTRMID_HERE/$toPartRMID/ig;
	$templContents =~s/FROMPARTGUID_HERE/$fromPartGUID/ig;
	$templContents =~s/FROMPARTRMID_HERE/$fromPartRMID/ig;
	$templContents =~s/TOPORTRMID_HERE/$toPortRMID/ig;
	$templContents =~s/TOPORTGUID_HERE/$toPortGUID/ig;
	$templContents =~s/FROMPORTGUID_HERE/$fromPortGUID/ig;	
	$templContents =~s/FROMPORTRMID_HERE/$fromPortRMID/ig;
	$templContents =~s/CONNNAME_HERE/$connName/ig;
	$templContents =~s/CONNGUID_HERE/$connGUID/ig;
	$templContents =~s/CONNRMID_HERE/$connRMID/ig;


	$templIndexContents =~s/PROJECTAREAID_HERE/$projectArea/ig;
	$templIndexContents =~s/CURRENTDATE_HERE/$date/ig;
	$templIndexContents =~s/TOPARTGUID_HERE/$toPartGUID/ig;
	$templIndexContents =~s/TOPARTRMID_HERE/$toPartRMID/ig;
	$templIndexContents =~s/FROMPARTGUID_HERE/$fromPartGUID/ig;
	$templIndexContents =~s/FROMPARTRMID_HERE/$fromPartRMID/ig;
	$templIndexContents =~s/TOPORTRMID_HERE/$toPortRMID/ig;
	$templIndexContents =~s/TOPORTGUID_HERE/$toPortGUID/ig;
	$templIndexContents =~s/FROMPORTGUID_HERE/$fromPortGUID/ig;	
	$templIndexContents =~s/FROMPORTRMID_HERE/$fromPortRMID/ig;
	$templIndexContents =~s/CONNNAME_HERE/$connName/ig;
	$templIndexContents =~s/CONNGUID_HERE/$connGUID/ig;
	$templIndexContents =~s/CONNRMID_HERE/$connRMID/ig;
	
open (READ_PRT, '<', $mainFileName);

while (<READ_PRT>){
	chomp($_);
	if ($origFileContents eq "") {
		$origFileContents = $_ . "\n";
	}
	else {
		$origFileContents = $origFileContents . $_ . "\n"; 
	}

}
close (READ_PRT);

my $fileContentsWithDCBlockAgg =  aggregateBlock($parentFromBlock, $connGUID, $origFileContents, "IClass");
$origFileContents = $fileContentsWithDCBlockAgg;

my $fileContentsWithConn = insertChild($origFileContents, $templContents, $parentFromBlock, "IClass");
$origFileContents = $fileContentsWithConn;

my $newConnIndexAddedFileContents = insertNewIndex($origFileContents, $templIndexContents, $parentFromBlock);
$origFileContents = $newConnIndexAddedFileContents;



my $trimmedFileContents = trimFileContents($origFileContents); 
$origFileContents = $trimmedFileContents;

#write to File... 
open (WR, '>', $mainFileName);
binmode WR;

my @contentArray = split(/\n/, $origFileContents);
foreach (@contentArray){
	chomp($_);
	print WR "$_\012"; 
}

close (WR);

fixRhapsodyIndicies($mainFileName);






# ======================= DELETE Below this line =============================



# my $blockPackageExists = "false";
# my $isSeperateFile = "false";
# my $newPortIds = getIds($searchPath);
# my $newPackageIds = getIds($searchPath);
# my $newCompositeIds = getIds($searchPath);

# my ($newPortGuid, $newPortRMId) = split(/,/,$newPortIds);







# # Search the port name within the workspace

# #use for Linux 
# # my $parentFolder = qx/find $fullPath \-type f \-exec grep \-H \'$newPort\' \{\} \\\;/;

# #use for Windows
# my $parentBlock = `findstr $portBlock $searchPath`;

 # if ($parentBlock eq "") {
	
	# print "ERROR: The Block could not be found. Please enter an existing Block to create the port\n\n\n";
	# exit -1; 
 # }

# chomp ($parentBlock); 
# my @file_list=split(/\n/, $parentBlock);

# open (IN, '>', 'test.txt');
# binmode IN;

# my $fileName = "";
# my $rest = "";

# for (@file_list){ 
	# ($fileName, $rest) = split(":\t", $_);
	# print IN "$fileName\012" ;
# }

# close (IN);


# #file operations: Open the file which keeps the parent block. 

# open (READ_PRT, '<', $fileName);

# while (<READ_PRT>){
	# chomp($_);
	# if ($origFileContents eq "") {
		# $origFileContents = $_ . "\n";
	# }
	# else {
		# $origFileContents = $origFileContents . $_ . "\n"; 
	# }

# }
# close (READ_PRT);

# #check if Port Exists 
# if (index($origFileContents, $newPort)!=-1) {
# print "Port Exists!!!\n\n\n";
# exit -1;
# }

# # Find the GUID of the Parent Block 
# my $blockGuid = findGuid($portBlock, $origFileContents, "IClass"); 


# if ($blockGuid eq "ERROR") {
	# print "Parent Block Cannot be found. Exiting..."; 
	# exit -1;
	# }
	
# # We'll create the port from the port template now: 
# my $newPortCreated = createNewPort($origFileContents, $newPortGuid, $newPortRMId, $newPort, $projectArea, $portSt, $fullPath);



# #Now insert the template into the correct file 
# my $fileContentsWithPort = insertChild($origFileContents, $newPortCreated, $portBlock, "IClass");
# $origFileContents = $fileContentsWithPort;



# my $fileContentsWithDCBlockAgg =  aggregateBlock($portBlock, $newPortGuid, $origFileContents, "IClass");
# $origFileContents = $fileContentsWithDCBlockAgg;

# my $createPortIndex = createNewPortIndex($newPortRMId, $newPortGuid, $projectArea, $newPort);
# my $newPortIndexAddedFileContents = insertNewIndex($origFileContents, $createPortIndex, $portBlock);
# $origFileContents = $newPortIndexAddedFileContents;



# my $newPortIndexAlsoAppendedToParentBlock = appendNewBlockToPackageIndex($portBlock, $newPortRMId, $projectArea, $origFileContents);
# $origFileContents = $newPortIndexAlsoAppendedToParentBlock;


# #set the stereotypes 

# # To find Stereotype first read the file 
# my $profileFile = $workspace . "Projekt_SETitanic_rpy\\Ports.sbsx"; 
# my $profileContents = ""; 

# open (READ_PROF, '<', $profileFile); 

# while (<READ_PROF>){
	# chomp($_);
	# if ($profileContents eq "") {
		# $profileContents = $_ . "\n";
	# }
	# else {
		# $profileContents = $profileContents . $_ . "\n"; 
	# }

# }
# close (READ_PROF);


# # my $level = 2; 
 # my $stName = $portSt; 
# # my $stGuid = findGuid($stName, $profileContents, "IStereotype"); 

# # my @parentName = ""; 
# # my @parentGuid = ""; 
# # my $recursiveParents = ""; 
# # if ($level ne "NA") {
	# # my $inGuid = $stGuid;
# # for (my $i = 0; $i < $level ; $i++) {
	# # $parentName[$i] = findParentName($inGuid, $profileContents, "ISubsystem");
	# # $parentGuid[$i] = findGuid($parentName[$i], $profileContents, "ISubsystem");
	# # $inGuid = $parentGuid[$i];
	# # if ($recursiveParents eq "") {$recursiveParents = $parentName[$i];}
	# # else {$recursiveParents = $parentName[$i] . "::" . $recursiveParents;} 	
	# # }	
# # }



# # my $stereotypeAdd = createNewStereotype($recursiveParents, $stName, $stGuid);  
# # $stereotypeAdd =~s/.\\..\\Profiles\\Gesamtsystem.sbsx/.\\PortSt.sbsx/ig;
# # $stereotypeAdd =~s/::PortSt/System_SETitanic::PortSt/ig;

# # my $stAddedFileContents = insertStereotype($origFileContents, $newPort, $stereotypeAdd, $stGuid, "IPort"); 
# # $origFileContents = $stAddedFileContents; 

# my $appendedStToBlockIndex = appendStToBlockIndex($origFileContents, $newPort, $stName);
# $origFileContents = $appendedStToBlockIndex; 


# my $trimmedFileContents = trimFileContents($origFileContents); 
# $origFileContents = $trimmedFileContents;

# #write to File... 
# open (WR, '>', $fileName);
# binmode WR;

# my @contentArray = split(/\n/, $origFileContents);
# foreach (@contentArray){
	# chomp($_);
	# print WR "$_\012"; 
# }

# close (WR);

# fixRhapsodyIndicies($fileName);



