

#!/usr/bin/perl

use warnings;
use strict;
use DateTime;
use libs;


# Initialize the global variables. 

#Linux
# my $workspace = "\/home\/parallels\/Desktop\/workspace2\/NVL\/";

#Windows 
my $workspace = "C:\\Users\\kerimcakmak\\workspace2\\NVL\\SETitanic\\";

my $rhapsody_file_dir = "Projekt_SETitanic_rpy\\";

my $fullPath = $workspace . "" . $rhapsody_file_dir;
my $searchPath = $fullPath . "\*.\*";

# inputs
my $blockToCreate = $ARGV[1];
my $parentBlock = $ARGV[0];

my $origFileContents = ""; 
my $parentGuid = "";
my $parentPackage = ""; 
my $blockPackageExists = "false";
my $isSeperateFile = "false";
my $newBlockIds = getIds($searchPath);
my $newPackageIds = getIds($searchPath);
my $newCompositeIds = getIds($searchPath);

my ($newBlockGuid, $newBlockRMId) = split(/,/,$newBlockIds);
my ($newPackageGuid, $newPackageRMId)  = split(/,/,$newPackageIds);
my ($newCompositeGuid, $newCompositeRMId) = split(/,/,$newCompositeIds);
my $projectArea = "iOjfYfj9Eeyg2Yb4jthRGQ";


my $blockPackage = (split "_", $blockToCreate) [-1];
$blockPackage = "ST_" . $blockPackage;

# Search the parent block in the files within the workspace

#use for Linux 
# my $parentFolder = qx/find $fullPath \-type f \-exec grep \-H \'$parentBlock\' \{\} \\\;/;

#use for Windows
my $parentFolder = `findstr $parentBlock $searchPath`;


 if ($parentFolder eq "") {
	
	print "ERROR: Parent Block could not be found. Please enter an existing Block as parent block\n\n\n";
	exit -1; 
 }

chomp ($parentFolder); 
my @file_list=split(/\n/, $parentFolder);

open (IN, '>', 'test.txt');
binmode IN;

my $fileName = "";
my $rest = "";

for (@file_list){ 
	($fileName, $rest) = split(":\t", $_);
	print IN "$fileName\012" ;
}

close (IN);


#file operations: Open the file which keeps the parent block. 

open (READ_PRT, '<', $fileName);

while (<READ_PRT>){
	chomp($_);
	if ($origFileContents eq "") {
		$origFileContents = $_ . "\n";
	}
	else {
		$origFileContents = $origFileContents . $_ . "\n"; 
	}

}
close (READ_PRT);

#check if Block Exists 
if (index($origFileContents, $blockToCreate)!=-1) {
print "Child Block Exists!!! Please try to create Link\n\n\n";
exit -1;
}

# Find the GUID of the Parent Block 
$parentGuid = findGuid($parentBlock, $origFileContents, "IClass"); 

if ($parentGuid eq "ERROR") {
	print "Parent Block Cannot be found. Exiting..."; 
	exit -1;
	}
	
# Identify the parent Package where the parent Block resides. 
# Then we have to create a sub package under this parent package 
# Then we have to create a sub block under the sub package 

$parentPackage = findParentName($parentGuid, $origFileContents, "ISubsystem"); 

# Now we have to create a sub package under this parent package 
# Then we have to create a sub block under the sub package 
# But before these actions, first lets check if there is a sub-package defined already for the new block

$blockPackageExists = checkBlockPackage($blockPackage, $origFileContents); 

#if there is already a package for the new child block
if ($blockPackageExists eq "true") {
	$isSeperateFile = isFile($blockPackage, $origFileContents); 
#if there is already a package for the new child block and it is also a seperate file. 
	if ($isSeperateFile eq "true"){
		my $relativeFile = (split /\\/, $fileName)[-1];
		my $newRelativeFile = $blockPackage . ".sbsx";
		$fileName =~s/$relativeFile/$newRelativeFile/ig;
# now the filename that we need to update has changed.  
	}
}	
	
# Now we have to create a sub package under this parent package 
# Then we have to create a sub block under the sub package 

# lets get the Rhapsody file contents again. In case the file to update is different from the beginning.. 
$origFileContents = "";
open (READ_PRT, '<', $fileName);

while (<READ_PRT>){
	chomp($_);
	if ($origFileContents eq "") {
		$origFileContents = $_ . "\n";
	}
	else {
		$origFileContents = $origFileContents . $_ . "\n"; 
	}

}
close (READ_PRT);

 


##From now on we create the Block and its package 
if ($blockPackageExists eq "false") {
#block Package doesn't exist. Create the packge first 
	my $newPackageCreated = createBlockPackage($blockPackage, $newPackageGuid, $newBlockGuid, $projectArea, $newPackageRMId, $newCompositeRMId, $newCompositeGuid);
#then insert th's block to the main file 
	my $fileContentsWithPackage = insertChild($origFileContents, $newPackageCreated, $parentPackage, "ISubsystem");  
	$origFileContents = $fileContentsWithPackage;
#add the new block to the aggreate list of the parent block  
	my $fileContentsWithPackageAgg = aggregateBlock($parentPackage, $newPackageGuid, $origFileContents, "ISubsystem");
	$origFileContents = $fileContentsWithPackageAgg;

}
# Now, the package exists, just add the block guid under the Block Package that exists
	my $fileContentsWithBlockAgg = aggregateBlock($blockPackage, $newBlockGuid, $origFileContents, "ISubsystem");
	$origFileContents = $fileContentsWithBlockAgg;

#now create the block 
# but first update the template
my $newBlockCreated = createNewBlock($origFileContents, $newBlockGuid, $newBlockRMId, $blockToCreate, $projectArea);


#Now insert the template into the correct file 
my $fileContentsWithBlock = insertChild($origFileContents, $newBlockCreated, $blockPackage, "ISubsystem");
$origFileContents = $fileContentsWithBlock;

#new Block is created and recorded in the origFileContents variable. We need to update the Rhapsody indicies now 



# check if there is already and index entry for the new package 
if (index($origFileContents, "<NAME>" . $blockPackage . "<\/NAME>")!=-1) {
#no need to create index for package. This index exists. So just, append the rm id of the new block 
	my $newBlockAppendedtoPackageIndex = appendNewBlockToPackageIndex($blockPackage, $newBlockRMId, $projectArea, $origFileContents);
	$origFileContents = $newBlockAppendedtoPackageIndex;
}

else {
 # Index doesn't exist for the package. First create the index for the package 
# then insert it to file Contents 
# finally, append the package to the parent package index. New Block will automatically been added to the block package index. No need to run the appendNewBlockToPackageIndex method for the block. 
	my $createPackageIndex = createNewPackageIndex($newPackageRMId, $newPackageGuid, $projectArea, $blockPackage, $newBlockRMId);
	my $newPackageIndexAddedFileContents = insertNewIndex($origFileContents, $createPackageIndex, $parentPackage);
	$origFileContents = $newPackageIndexAddedFileContents; 
	my $newPackageIndexAlsoAppendedToParent = appendNewBlockToPackageIndex($parentPackage, $newPackageRMId, $projectArea, $origFileContents);
	$origFileContents = $newPackageIndexAlsoAppendedToParent;
}

#now create the Block index the block is already appended to the package index 

my $createBlockIndex = createNewBlockIndex($newBlockRMId, $newBlockGuid, $projectArea, $blockToCreate);
my $newBlockIndexAddedFileContents = insertNewIndex($origFileContents, $createBlockIndex, $blockPackage);
 $origFileContents = $newBlockIndexAddedFileContents;
 
#Directed Composition Functions 
	# 1. Create a Directed Composition between child and parent.  
my $dcIds = getIds($searchPath);
my($dcGuid, $dcRmid) = split(/,/,$dcIds); 

	# 2. Create DC and DC index from template 
my $dcEntry = createNewDC($dcGuid, $dcRmid, $blockToCreate, $projectArea, $newBlockGuid, $newBlockRMId);
my $dcIndex = createNewDCIndex($dcRmid, $dcGuid, $projectArea, $blockToCreate, $newBlockRMId); 

	#3. Add DC (part) right after the "Class" tag of the Parent Block 
my $newBlockDCAddedFileContents = insertChild($origFileContents, $dcEntry, $parentBlock, "IClass");
$origFileContents = $newBlockDCAddedFileContents;

	#4. Add DC GUID to the Parent Block's aggregations 
my $fileContentsWithDCBlockAgg =  aggregateBlock($parentBlock, $dcGuid, $origFileContents, "IClass");
$origFileContents = $fileContentsWithDCBlockAgg;

	#5. Add DC to RM Server index 
my $insertNewDCIndex = insertNewIndex($origFileContents, $dcIndex, $parentBlock);
 $origFileContents = $insertNewDCIndex;

	#6. Add DC RMId to Rhapsody indicies (to parent Block)
my $newdcIndexAlsoAppendedToParentBlock = appendNewBlockToPackageIndex($parentBlock, $dcRmid, $projectArea, $origFileContents);
$origFileContents = $newdcIndexAlsoAppendedToParentBlock;
 
my $trimmedFileContents = trimFileContents($origFileContents); 
$origFileContents = $trimmedFileContents;

#write to File... 
open (WR, '>', $fileName);
binmode WR;

my @contentArray = split(/\n/, $origFileContents);
foreach (@contentArray){
	chomp($_);
	print WR "$_\012"; 
}

close (WR);

fixRhapsodyIndicies($fileName);



