
package libs;

use warnings;
use strict;
use DateTime;
use Exporter;



# these are exported by default.
our @EXPORT = qw( trimFileContents createNewBlockIndex insertNewIndex appendNewBlockToPackageIndex createNewPackageIndex insertChild createNewBlock createBlockPackage aggregateBlock getRMId getGuid findGuid findParentName checkBlockPackage isFile getDate );


sub trimFileContents {
	my $fileContents = $_[0]; 
	my $newContent = "";
	
	my @contentArr = split(/\n/, $fileContents); 
	
	foreach (@contentArr) {
		chomp($_); 
		if ($_ eq "") {next;} 
		
		$_ =~s/\n//ig;
		
		if ($newContent eq "") {$newContent = $_ . "\n";}
		else {
			$newContent =  $newContent. "\n" . $_;
		}
		
	}
	
	return $newContent; 
	
}


sub createNewBlockIndex{
	my $rmid = $_[0];
	my $guid = $_[1]; 
	my $projectArea = $_[2]; 
	my $blockName = $_[3];
	my $currentDate = getDate(); 
	my $templateContents = ""; 
	
	open(TEMPL, '<', "block_index_template.xml"); 
	while (<TEMPL>) {
		chomp($_); 
		if ($templateContents eq "") {$templateContents = $_ . "\n";} 
		else {$templateContents = $templateContents . $_ . "\n";} 
	}
	
	close(TEMPL);
	
	$templateContents =~s/BLOCKRMID_HERE/$rmid/ig;
	$templateContents =~s/BLOCKGUID_HERE/$guid/ig;
	$templateContents =~s/PROJECTAREAID_HERE/$projectArea/ig;
	$templateContents =~s/BLOCKNAME_HERE/$blockName/ig;
	$templateContents =~s/CURRENTDATE_HERE/$currentDate/ig;
	
	return $templateContents; 

}

sub insertNewIndex{
	my $fileContents = $_[0];
	my $packageIndex = $_[1];
	my $parentPackage = $_[2];
	my $fileContentsWithIndex = ""; 
	my $inIndex ="false";
	my $inParentPackage = "false"; 
	
	my @contentArr=split(/\n/, $fileContents); 
	
	foreach(@contentArr) {
		chomp($_); 
		my $line = $_; 

		my $lineReplace = "</ELEMENT>\n" . $packageIndex . "\n";
		
		if ($inParentPackage eq "true") {
			if (index($line, "<\/ELEMENT>")!=-1) {
				$line =~s/<\/ELEMENT>/$lineReplace/ig;
				$inParentPackage = "false"; 
			}
			$fileContentsWithIndex = $fileContentsWithIndex . "\n" . $line;
		}
		else {
			if ($fileContentsWithIndex eq "") {$fileContentsWithIndex = $line . "\n";} 
			else {$fileContentsWithIndex = $fileContentsWithIndex . "\n" . $line;}
		}
		if (index($line, "<RHAPSODY-INDEX>")!=-1) {$inIndex = "true";}
		if (index($line, "<\/RHAPSODY-INDEX>")!=-1) {
			$inIndex = "false";
		}
		
		if (($inIndex eq "true") and (index($line, "<NAME>" . $parentPackage . "<\/NAME>")!=-1)){$inParentPackage = "true";}		
	}
	
	return $fileContentsWithIndex;
	
}

sub appendNewBlockToPackageIndex {
	my $blockPackage = $_[0]; 
	my $blockRmid = $_[1];
	my $projectArea = $_[2];
	my $fileContents = $_[3];
	my $inElement = "false"; 
	my $inPackage = "false"; 
	my $fileContentsWithBlockAgg = "";
	
	my @contentArr = split(/\n/, $fileContents);
	
	foreach(@contentArr) {
		chomp($_); 
		my $line = $_; 
		if (index($line, "<ELEMENT>") != -1) {$inElement = "true";}
		if (index($line, "<\/ELEMENT>")!=-1) {
			$inElement = "false";
			$inPackage = "false";
		}
		
		if (($inElement eq "true") and (index($line, "<NAME>" . $blockPackage)!=-1)){$inPackage = "true";} 
		
		if ($inPackage eq "true") {
			if (index($line, "<AGGREGATES>")!=-1) {
				my $aggregated = $line; 
				$aggregated =~s/<AGGREGATES>//ig;
				$aggregated =~s/<\/AGGREGATES>//ig;
				$aggregated =~s/\t//ig;
				my $lineReplace = "";	
				if ($aggregated eq "") {
					$lineReplace = "<AGGREGATES>I:" . $blockRmid . "_" . $projectArea . "<\/AGGREGATES>"; 		
				}
				else {
					$lineReplace = "<AGGREGATES>I:" . $blockRmid . "_" . $projectArea . " | " . $aggregated . "<\/AGGREGATES>"; 
				}
				
				$line = $lineReplace;
		
			}
			
		}
		
		if ($fileContentsWithBlockAgg eq "") {$fileContentsWithBlockAgg = $line . "\n";}
		else {
			$fileContentsWithBlockAgg = $fileContentsWithBlockAgg . "\n" . $line; 
		}
		
	}
	
	return $fileContentsWithBlockAgg;
	
}

sub createNewPackageIndex {
	my $rmid = $_[0];
	my $guid = $_[1];
	my $projectArea = $_[2];
	my $packageName = $_[3];
	my $currentDate = getDate();
	my $blockRmid = $_[4];
	my $templateContents = "";
	
	open(TEMPL, '<', "package_index_template.xml"); 
	while (<TEMPL>) {
		chomp($_); 
		if ($templateContents eq "") {$templateContents = $_ . "\n";} 
		else {$templateContents = $templateContents . $_ . "\n";} 
	}
	
	close(TEMPL);
	
	$templateContents =~s/PACKAGERMID_HERE/$rmid/ig;
	$templateContents =~s/PACKAGEGUID_HERE/$guid/ig;
	$templateContents =~s/PROJECTAREAID_HERE/$projectArea/ig;
	$templateContents =~s/PACKAGENAME_HERE/$packageName/ig;
	$templateContents =~s/CURRENTDATE_HERE/$currentDate/ig;
	$templateContents =~s/BLOCKRMID_HERE/$blockRmid/ig;
	
	return $templateContents; 	
	
}


sub insertChild {
	my $fileContents = $_[0];
	my $blockTemplate = $_[1];
	my $blockPackage = $_[2];
	my $inType = "false";
	my $fileContentsWithBlock = ""; 
	my $inBlockPackage = ""; 
	
	my @contentArr = split(/\n/, $fileContents); 
	foreach(@contentArr) {
		chomp($_);
		my $line = $_;
		
		my $lineReplace = "</ISubsystem>\n\t" . $blockTemplate . "\n";
		
		if ($inBlockPackage eq "true") {
			$line =~s/<\/ISubsystem>/$lineReplace/ig;
			$fileContentsWithBlock = $fileContentsWithBlock . "\n" . $line;
		}
		else {
			if ($fileContentsWithBlock eq "") {$fileContentsWithBlock = $line . "\n";} 
			else {$fileContentsWithBlock = $fileContentsWithBlock . "\n" . $line;}
		}
		
		
		
		if (index($line, "<ISubsystem type")!=-1) {$inType = "true";} 
		if (index($line, "<\/ISubsystem>")!=-1) {
			$inType = "false";	
			$inBlockPackage = "false";
		} 
		
		if (($inType eq "true") and (index($line, "<_name type=\"a\">$blockPackage<\/_name>")!=-1)){$inBlockPackage = "true";}
		
	}
	
	return $fileContentsWithBlock; 
	
	
}

sub createNewBlock{
	my $fileContents = $_[0]; 
	my $guid = $_[1];
	my $rmid = $_[2];
	my $blockName = $_[3];
	my $projectArea = $_[4]; 
	my $currentDate = getDate();
	my $templateContents = "";
	
	open (PT, '<', "block_template.xml") ; 
	while(<PT>) {
		chomp($_); 
		if ($templateContents eq "") {$templateContents = $_ . "\n";} 
		else {$templateContents = $templateContents . $_ . "\n";} 
	}
	
	close (PT); 
	
	$templateContents =~s/BLOCKGUID_HERE/$guid/ig;
	$templateContents =~s/BLOCKRMID_HERE/$rmid/ig;
	$templateContents =~s/PROJECTAREAID_HERE/$projectArea/ig;
	$templateContents =~s/BLOCKNAME_HERE/$blockName/ig;
	$templateContents =~s/CURRENTDATE_HERE/$currentDate/ig;
	
	return $templateContents; 
	
}

sub createBlockPackage{
	
	my $packageName = $_[0];
	my $packageGuid = $_[1];
	my $blockGuid = $_[2];
	my $projectArea = $_[3];
	my $packageRMId = $_[4];
	my $compositeGuid = getGuid(); 	
	my $templateContents = "";
	my $currentDate = getDate();
	
	open (PT, '<', "package_template.xml") ; 
	while(<PT>) {
		chomp($_); 
		if ($templateContents eq "") {$templateContents = $_ . "\n";} 
		else {$templateContents = $templateContents . $_ . "\n";} 
	}
	
	close (PT); 
	
	$templateContents =~s/PACKAGEGUID_HERE/$packageGuid/ig;
	$templateContents =~s/PACKAGERMID_HERE/$packageRMId/ig;
	$templateContents =~s/PROJECTAREAID_HERE/$projectArea/ig;
	$templateContents =~s/PACAKGENAME_HERE/$packageName/ig;
	$templateContents =~s/COMPOSITEGUID_HERE/$compositeGuid/ig;
	$templateContents =~s/CURRENTDATE_HERE/$currentDate/ig;
	$templateContents =~s/BLOCKGUID_HERE/$blockGuid/ig;

	return $templateContents; 
	
}

sub aggregateBlock{
	
	
	my $package = $_[0];
	my $guid = $_[1];
	my $fileContents = $_[2];
	my @contentArr = split(/\n/,$fileContents);
	my $inType = "false";
	my $inBlock = "false";
	my $inAggregation = "false";
	my $fileContentsWithBlockAgg = "";
	
	foreach(@contentArr) {
		chomp($_);
		my $line = $_;		
		if (index($line, "<ISubsystem type") != -1) {$inType = "true";}
		if (index($line, "<\/ISubsystem>") != -1) {
			$inType = "false"; 
			$inBlock = "false";
			$inAggregation = "false";
		}
		
		if (($inType eq "true") and (index($line, "<_name type=\"a\">" . $package) !=-1))  {$inBlock = "true"; }
		
		if (($inBlock eq "true") and (index($line, "<AggregatesList type") !=-1)){$inAggregation = "true";} 
		
		if ($inAggregation eq "true"){
			my $newBlockAggregate = "<value>" . $guid . "<\/value>\n<\/AggregatesList>"; 
			$line =~s/<\/AggregatesList>/$newBlockAggregate/ig; 
			if (index($line,$guid)!=-1){$inAggregation = "false";}
			$fileContentsWithBlockAgg = $fileContentsWithBlockAgg . "\n" . $line; 
		}
		else {
			if ($fileContentsWithBlockAgg eq "") {$fileContentsWithBlockAgg = $line . "\n";}
			else {
				$fileContentsWithBlockAgg = $fileContentsWithBlockAgg . "\n" . $line; 
			}
		}	
	}
	
	return $fileContentsWithBlockAgg;
	
	
	
	
	
}

sub getRMId{
	my $retRMId=""; 
	my $newList="";
	my $searchP = $_[0];
	
	open(RRMID, '<', "rmIDs.txt");
	while(<RRMID>){
		chomp($_);
		if ($_ eq "") {next;}
		if ($retRMId eq ""){
			my $idExists = `findstr $_ $searchP`;
			chomp($idExists);
			if ($idExists eq ""){$retRMId = $_;}
			
			}
		else {$newList = $newList . "\n" . $_;}		
	}
	close (RRMID);	
	
	open(WRMID, '>', "rmIDs.txt");
	print WRMID $newList;
	close (WRMID);
	return $retRMId;
	
}

sub getGuid{
	my $retGUID = "";
	my $newList = "";
	open(RGUID, '<', "GUIDs.txt");
	while(<RGUID>){
		chomp($_);
		if ($retGUID eq ""){$retGUID = $_;}
		else {$newList = $newList . "\n" . $_;}		
	}
	close (RGUID);
	
	open(WGUID, '>', "GUIDs.txt");
	print WGUID $newList;
	close (WGUID);
	return "GUID " . $retGUID;
}

sub findGuid{
	my $blockName = $_[0];
	my $contents = $_[1];
	my $type = $_[2];
	my $inType = "false";
	my $guidProspect = "";
	my $guid = "";
	
	my @contentsArray = split(/\n/, $contents); 


	foreach (@contentsArray) {
		chomp($_); 
		my $line = $_; 
		if (index($line, "<" . $type . " type") != -1) {$inType = "true";}
		if (index($line, "<\/" . $type . ">") != -1) {$inType = "false"; }
		
		if ((index($line, "<_id type") != -1) and ($inType eq "true")) {
			$line =~s/<_id type=\"a\">//ig;
			$line =~s/<\/_id>//ig;
			$line =~s/\t//ig;

			$guidProspect = $line; 
		}
		
		if ((index($line, "<_name type") != -1) and ($inType eq "true")) {
			$line =~s/<_name type=\"a\">//ig;
			$line =~s/<\/_name>//ig; 
			$line =~s/\t//ig;
			
			if ($line eq $blockName) {$guid = $guidProspect;}
		}			
		
	}	

	if (index($guid, "GUID") != -1) {
	return $guid; 
	}
	
	else {return "ERROR";}
	
}

sub findParentName{
	my $guid = $_[0]; 
	my $contents = $_[1]; 
	my $type = $_[2];
	my $inType = "false"; 
	my $inAggregations = "false";
	my $nameProspect = ""; 
	my $name =""; 
	
	my @contentsArray = split(/\n/, $contents); 
	
	foreach (@contentsArray) {
		chomp($_); 
		my $line = $_; 
		if (index($line, "<" . $type . " type") != -1) {$inType = "true"; }
		if (index($line, "<\/" . $type. ">") != -1) {$inType = "false";} 
		if ((index($line, "<_name type") != -1) and ($inType eq "true")) {
			$line =~s/<_name type=\"a\">//ig;
			$line =~s/<\/_name>//ig;
			$line =~s/\t//ig;
			$nameProspect = $line; 
		}

		if ((index($line, "<AggregatesList type") != -1) and ($inType eq "true")) {$inAggregations = "true";}
		if ((index($line, "<\/AggregatesList>") != -1) and ($inType eq "true")) {$inAggregations = "false";}
		
		if ($inType eq "true" and $inAggregations eq "true") {
			$line =~s/<value>//ig;
			$line =~s/<\/value>//ig;
			$line =~s/\t//ig;	
			
			if ($line eq $guid) {$name = $nameProspect;} 
		}
		
		}

	return $name; 
		
	}

sub checkBlockPackage{
	my $packageName = $_[0];
	my $contents = $_[1];
	
	if (index($contents,$packageName)!=-1){
		return "true";
	}
	else{return "false";}
}
	
sub isFile{
	my $packageName = $_[0];
	my $contents = $_[1];
	my $isFile = "true";
	
	my @contentsArray = split(/\n/, $contents); 
	
	foreach(@contentsArray) {
		chomp($_);
		my $line = $_;
		if ((index($line,$packageName) !=-1) and (index($line, "fileName") !=-1)) {
			$isFile = "true";
			return $isFile;
		}
		if ((index($line,$packageName) !=-1) and (index($line, "<_name") !=-1)) {
			$isFile = "false";
			return $isFile;
		}
	}
}

sub getDate {
	
	my $dt = DateTime -> now;
	my $date = 	$dt->mdy;
	$date =~s/-/./ig;
	my $time = $dt->hms; 
	
	return $date . "::" . $time;

}


 1;