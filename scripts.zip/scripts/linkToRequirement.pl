#!/usr/bin/perl
use warnings;
use strict;
use libs; 

my $workspace = "C:\\Users\\kerimcakmak\\workspace2\\NVL\\SETitanic\\";
my $rhapsody_file_dir = "Projekt_SETitanic_rpy\\";
my $block = $ARGV[0];
my $type = $ARGV[1];
my $fullPath = $workspace . "" . $rhapsody_file_dir;
my $searchPath = $fullPath . "\*.\*";
my $origFileContents = "";
my $targetLink = "https://jazz.net/sandbox01-rm/resources/BI_H6ar9SnLEe2zB-tVgYH0_w";

my $parentFolder = `findstr $block $searchPath`;


 if ($parentFolder eq "") {
	
	print "ERROR: Parent Block could not be found. Please enter an existing Block as parent block\n\n\n";
	exit -1; 
 }

chomp ($parentFolder); 
my @file_list=split(/\n/, $parentFolder);

open (IN, '>', 'test.txt');
binmode IN;

my $fileName = "";
my $rest = "";

for (@file_list){ 
	($fileName, $rest) = split(":\t", $_);
	print IN "$fileName\012" ;
}

close (IN);

#file operations: Open the file which keeps the parent block. 

open (READ_PRT, '<', $fileName);

while (<READ_PRT>){
	chomp($_);
	if ($origFileContents eq "") {
		$origFileContents = $_ . "\n";
	}
	else {
		$origFileContents = $origFileContents . $_ . "\n"; 
	}

}
close (READ_PRT);

# find the rmserverID of the Block to be linked 
my $rmServerID = findRmid($block, $origFileContents, "I" . $type);
# find the GUID of the block to be linked 
my $GUID = findGuid($block, $origFileContents, "I" . $type);



my $oslcLink = "<IOslcLink type=\"e\">
				<_source type=\"a\">" . $rmServerID . "<\/_source>
				<_sourceGUID type=\"a\">" . $GUID . "<\/_sourceGUID>
				<_target type=\"a\">" . $targetLink . "<\/_target>
				<_type type=\"a\">http://jazz.net/ns/dm/linktypes#trace<\/_type>
				</IOslcLink>";
				
my $linkExists = findIfOSLCExists($origFileContents, $targetLink, $rmServerID);

if ($linkExists eq "false") {
	my $oslcInserted = insertOSLC($origFileContents, $oslcLink);
	$origFileContents = $oslcInserted;
}


#write to File... 
open (WR, '>', $fileName);
binmode WR;

my @contentArray = split(/\n/, $origFileContents);
foreach (@contentArray){
	chomp($_);
	print WR "$_\012"; 
}

close (WR);

fixRhapsodyIndicies($fileName);